// Get all the elements
const btnAddToCart = document.querySelectorAll('.btn-add-to-cart');
const cartItems = document.getElementById('cart-items');
const totalAmount = document.getElementById('total-amount');
const btnCheckout = document.getElementById('btn-checkout');

let cart = []; // Store cart items

// Add event listener for "Add to Cart" button
btnAddToCart.forEach(btn => {
  btn.addEventListener('click', (e) => {
    const menuItem = e.target.parentElement;
    const item = {
      name: menuItem.querySelector('img').alt,
      price: parseInt(menuItem.querySelector('.price').innerText.slice(1))
    };
    cart.push(item);
    updateCart();
  });
});

// Update cart and total amount
function updateCart() {
  cartItems.innerHTML = '';
  totalAmount.innerText = '0';
  cart.forEach(item => {
    const li = document.createElement('li');
    li.innerText = `${item.name} - $${item.price}`;
    cartItems.appendChild(li);
    totalAmount.innerText = parseInt(totalAmount.innerText) + item.price;
  });
}

// Add event listener for "Checkout" button
btnCheckout.addEventListener('click', () => {
  // Implement your checkout logic here
  // You can access the cart array to get the items in the cart
  // You can also access the total amount using the totalAmount.innerText
});